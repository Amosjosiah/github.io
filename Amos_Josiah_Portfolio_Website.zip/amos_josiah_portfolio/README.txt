AMOS JOSIAH OLUWATOSIN — PORTFOLIO WEBSITE

FILES
- index.html: responsive portfolio website
- assets/AmosJosiah_Resume.pdf: CV linked from the website

PREVIEW LOCALLY
1. Keep the index.html file and assets folder together.
2. Double-click index.html to open it in your browser.

PUBLISH FREE WITH GITHUB PAGES
1. Sign in or create an account at https://github.com/
2. Create a new public repository. A repository named YOURUSERNAME.github.io can be used for a user site.
3. Upload index.html and the assets folder (including the PDF) to the repository root.
4. If using a normal repository, open Settings > Pages and configure deployment from the main branch and root folder.
5. Wait for GitHub Pages to publish, then open the URL shown in Settings > Pages.

ALTERNATIVE: NETLIFY
You can deploy by uploading the unzipped site folder through Netlify's manual deploy/drop workflow, if available on your account.

BEFORE PUBLISHING
- Check that your email, phone number, location, job titles, employers, and dates are correct and that you want them public.
- Work samples are explicitly labeled illustrative; replace/add only genuine work you are permitted to share.
- This package is prepared for deployment; it is not yet hosted at a public live URL.
